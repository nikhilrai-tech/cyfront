from django.http import HttpResponse
from django.shortcuts import render

from rest_framework.permissions import AllowAny, IsAuthenticated, IsAdminUser
from rest_framework.authentication import SessionAuthentication, TokenAuthentication
from rest_framework_simplejwt.authentication import JWTTokenUserAuthentication
from rest_framework.decorators import api_view, permission_classes, authentication_classes 
from rest_framework.response import Response
# Create your views here.
from .models import *
from .serializers import *
from django.contrib.auth import get_user_model
from back.bviews import IsCompany
from other.notis import add_noti_single
from rest_framework import permissions


User = get_user_model()



class HasPermissionBase(permissions.BasePermission):
    """
    Allows access only to users who have the appropriate permission.
    """

    permission_codename = ""

    def has_permission(self, request, view):
        print('in has perm',self.permission_codename)
        user = User.objects.get(id=request.user.id)
        print(user.has_perm('main.view_report'))
        return user.has_perm(self.permission_codename)


def HasPermission(permission_codename):
    return type('HasPermission', (HasPermissionBase, ), {'permission_codename': permission_codename})











    

@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def getjobs(request,location='',type=0):
    user = User.objects.get(id=request.user.id)
    if request.method == 'GET':
        if user.type == 'U':
          #  print(type)
            locations = Job.objects.all().values_list("location").distinct()
            if len(location) > 0:
                fillocs = location.split(',')
            else:
                fillocs = locations
            if type==1 or type=='1':
              #  print('1')
                jobs = Job.objects.filter(location__in=fillocs,type='F').order_by('-lastedited')
            elif type==2 or type=='2':
              #  print('2')
                jobs = Job.objects.filter(location__in=fillocs,type='C').order_by('-lastedited')
            else:
              #  print('3')
                jobs = Job.objects.filter(location__in=fillocs).order_by('-lastedited')
            job=JobSerializer(jobs, many=True)
            return Response({"jobs": job.data,"locations": locations})
        if user.type == 'C':
            jobs = Job.objects.filter(posted_by=user).order_by('-lastedited')
            job=JobSerializer(jobs, many=True)
            return Response({"jobs": job.data})
        if user.type == 'Ct':
            jobs = Job.objects.filter(posted_by=user.refuser).order_by('-lastedited')
            job=JobSerializer(jobs, many=True)
            return Response({"jobs": job.data})
    if request.method == 'POST':
        if user.type == 'C':
            if Job.objects.filter(designation=request.data['title']).exists():
                return Response({"error": True,"message": "Job already exists with this title"})
            newjob = Job(posted_by=user, type=request.data['type'], designation=request.data['title'], description=request.data['description'], link=request.data['link'],
             remote=request.data['remote'], out=request.data['out'])
            newjob.save()
            if 'scopes' in request.data:
                for sc in request.data['scopes']:
                    scope = Scope.objects.get(id=sc)
                    newjob.scopes.add(scope)
            job=JobSerializer(newjob, many=False)
            return Response({"job": job.data,"message": "Job successfully added","show": True})
        elif user.type == 'Ct':
            if Job.objects.filter(designation=request.data['title']).exists():
                return Response({"error": True,"message": "Job already exists with this title"})
            newjob = Job(posted_by=user.refuser, type=request.data['type'], designation=request.data['title'], description=request.data['description'], link=request.data['link'],
             remote=request.data['remote'], out=request.data['out'])
            newjob.save()
            if 'scopes' in request.data:
                for sc in request.data['scopes']:
                    scope = Scope.objects.get(id=sc)
                    newjob.scopes.add(scope)
            job=JobSerializer(newjob, many=False)
            return Response({"job": job.data,"message": "Job successfully added","show": True})
        else:
            return Response({"scopes": "Unauthorized"})
    

















def check_report_perm(user, report):
    perm = False
    if user.type == 'U':
        perm = report.posted_by.id == user.id
    elif user.type == 'C':
        perm = report.program.posted_by.id == user.id
    elif user.type == 'Ct':
        perm = report.program.posted_by.id == user.refuser.id
    else:
        perm = False
    return report.disclosure or perm










































    

@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def getprograms(request):
    user = User.objects.get(id=request.user.id)
    # users = User.objects.filter(refuser__in=[user])
    # print(users)
    if request.method == 'GET':
        if user.type == 'U':
            programs = Program.objects.all().order_by('-lastedited')
            program=ProgramSerializer(programs, many=True, context={'request': request})
            return Response({"programs": program.data})
        elif user.type == 'C':
            programs = Program.objects.filter(posted_by=user).order_by('-lastedited')
            program=ProgramSerializer(programs, many=True, context={'request': request})
            return Response({"programs": program.data})
        elif user.type == 'Ct':
            programs = Program.objects.filter(posted_by=user.refuser).order_by('-lastedited')
            program=ProgramSerializer(programs, many=True, context={'request': request})
            return Response({"programs": program.data})
        else:
            return Response({"programs": "Unauthorized"})
    if request.method == 'POST':
        if user.type == 'C':
            if Program.objects.filter(title=request.data['title']).exists():
                return Response({"error": True,"message": "Program already exists with this title"})
            newprogram = Program(posted_by=user, type=request.data['type'], title=request.data['title'], policy=request.data['description'], lowreward=request.data['low'], 
            midreward=request.data['mid'],highreward=request.data['high'],criticreward=request.data['critic'], managed=request.data['managed'], splitting=request.data['splitting'])
            newprogram.save()
            if 'scopes' in request.data:
                for sc in request.data['scopes']:
                    scope = Scope.objects.get(id=sc)
                    newprogram.scopes.add(scope)
            program=ProgramSerializer(newprogram, many=False, context={'request': request})
            return Response({"program": program.data,"message": "Program successfully added","show": True})
        elif user.type == 'Ct':
            if Program.objects.filter(title=request.data['title']).exists():
                return Response({"error": True,"message": "Program already exists with this title"})
            newprogram = Program(posted_by=user.refuser, type=request.data['type'], title=request.data['title'], policy=request.data['description'], lowreward=request.data['low'], 
            midreward=request.data['mid'],highreward=request.data['high'],criticreward=request.data['critic'], managed=request.data['managed'], splitting=request.data['splitting'])
            newprogram.save()
            if 'scopes' in request.data:
                for sc in request.data['scopes']:
                    scope = Scope.objects.get(id=sc)
                    newprogram.scopes.add(scope)
            program=ProgramSerializer(newprogram, many=False, context={'request': request})
            return Response({"program": program.data,"message": "Program successfully added","show": True})
        else:
            return Response({"scopes": "Unauthorized"})
            

    

@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def program(request, pid):
    user = User.objects.get(id=request.user.id)
    # users = User.objects.filter(refuser__in=[user])
    # print(users)
    # print(pid)
    pid = pid.replace('+',' ')
    # print(pid)
    if request.method == 'GET':
        try:
            programs = Program.objects.get(title=pid)
        except:
            return Response({'error': True,'message': 'Program not found'})
        if user.type in ['U','C','Ct']:
            program=ProgramSerializerMore(programs, many=False, context={'request': request})
            return Response(program.data)
        else:
            return Response({"program": "Unauthorized"})
    if request.method == 'POST':
        try:
            programs = Program.objects.get(title=pid)
        except:
            return Response({'error': True,'message': 'Program not found'})
        if user.type in ['C','Ct']:
            programs = Program.objects.get(title=pid)
            print(request.data)
            program=ProgramSerializerMore(programs, many=False, context={'request': request})
            return Response(program.data)
        else:
            return Response({"program": "Unauthorized"})
    

    

@api_view(['POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsCompany])
def background(request, pid):
    pid = pid.replace('+',' ')
    user = User.objects.get(id=request.user.id)
    if user.type == 'C':
        program = Program.objects.get(title=pid)
        name = request.data['photo'].name
        if name.split('.')[1] not in ['png','jpg','jpeg']:
            return Response({'error': True,'message': 'Please Upload a proper image'})
        program.background = request.data['photo']
        program.save()
        return Response({"error": False})
    



@api_view(['GET'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def favorite(request,prog=None,type=None): 
    # print(request.META)
    prog = prog.replace('+',' ')
    if request.method == 'GET':
        # print(request.user)
        if prog==None or type==None:
            return Response({'error': True, 'message': 'Unauthorized'})
        else:
            try:
                program = Program.objects.get(title=prog)
            except:
                return Response({'error': True, 'message': 'Program Not Found'})
            user = User.objects.get(id=request.user.id)
            if user.type == 'U':
                if type=='1':
                    program.subscribed.add(user)
                    add_noti_single(user, 'Added to Favourites',f"{program.title} was successfully added to your favourites.",link=f'/p/?{program.title}',avatar=program.background.url if program.background else None)
                    return Response({"message": "Added Program to Favorites","show": True})
                elif type=='2':
                    program.subscribed.remove(user)
                    add_noti_single(user, 'Removed from Favourites',f"{program.title} was successfully removed from your favourites.",ntype='E',link=f'/p/?{program.title}',avatar=program.background.url if program.background else None)
                    return Response({"message": "Removed Program from Favorites","show": True})
                else:
                    return Response({"message": "Something Went Wrong","show": True})
            else:
                return Response({'error': True, 'message': 'Unauthorized'})



    

































































@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsCompany])
def getscopes(request):
    if request.method == 'GET':
        user = User.objects.get(id=request.user.id)
        if user.type == 'C':
            scope = Scope.objects.filter(company=user)
            scopes=ScopeSerializer(scope, many=True)
            return Response({"scopes": scopes.data})
        elif user.type == 'Ct':
            scope = Scope.objects.filter(company=user.refuser)
            scopes=ScopeSerializer(scope, many=True)
            return Response({"scopes": scopes.data})
        else:
            return Response({"scopes": "Unauthorized"})
    if request.method == 'POST':
        user = User.objects.get(id=request.user.id)
        if user.type == 'C':
            scoped = Scope(company=user, type=request.data['type'], severity=request.data['severity'], tags=request.data['tags'], out=request.data['out'], bounty=request.data['bounty'], domain=request.data['domain'])
            scoped.save()
            scope = Scope.objects.filter(company=user)
            scopes=ScopeSerializer(scope, many=True)
            return Response({"scopes": scopes.data,"message": "Scope successfully added","show": True})
        elif user.type == 'Ct':
            scoped = Scope(company=user.refuser, type=request.data['type'], severity=request.data['severity'], tags=request.data['tags'], out=request.data['out'], bounty=request.data['bounty'], domain=request.data['domain'])
            scoped.save()
            scope = Scope.objects.filter(company=user.refuser)
            scopes=ScopeSerializer(scope, many=True)
            return Response({"scopes": scopes.data,"message": "Scope successfully added","show": True})
        else:
            return Response({"scopes": "Unauthorized"})


            

    

@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsCompany])
def scope(request,sid):
    if request.method == 'GET':
        user = User.objects.get(id=request.user.id)
        if user.type == 'C':
            scope = Scope.objects.get(id=sid)
            scope.delete()
            return Response({"error": False})
        elif user.type == 'Ct':
            scope = Scope.objects.get(id=sid)
            scope.delete()
            return Response({"error": False})
        else:
            return Response({"scopes": "Unauthorized"})
    if request.method == 'POST':
        user = User.objects.get(id=request.user.id)
        if user.type == 'C':
            scope = Scope.objects.get(id=sid)
            scope.type = request.data['type']
            scope.severity = request.data['severity'] if 'severity' in request.data else None
            scope.tags = request.data['tags'] if 'tags' in request.data else ''
            scope.out = request.data['out'] if 'out' in request.data else False
            scope.bounty = request.data['bounty'] if 'bounty' in request.data else False
            scope.domain = request.data['domain']
            scope.save()
            scopes=ScopeSerializer(scope, many=False)
            return Response({"scope": scopes.data,"message": "Scope successfully edited","show": True})
        elif user.type == 'Ct':
            scope = Scope.objects.get(id=sid)
            scope.type = request.data['type']
            scope.severity = request.data['severity'] if 'severity' in request.data else None
            scope.tags = request.data['tags'] if 'tags' in request.data else ''
            scope.out = request.data['out'] if 'out' in request.data else False
            scope.bounty = request.data['bounty'] if 'bounty' in request.data else False
            scope.domain = request.data['domain']
            scope.save()
            scopes=ScopeSerializer(scope, many=True)
            return Response({"scope": scopes.data,"message": "Scope successfully edited","show": True})
        else:
            return Response({"scope": "Unauthorized"})




            
            









































            



@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def reportpl(request, pid=None):
    user = User.objects.get(id=request.user.id)
    # users = User.objects.filter(refuser__in=[user])
    # print('entered here')
    # print(pid)
    if pid:
        pid = pid.replace('+',' ')
    # print(pid)
    if request.method == 'GET':
        if pid==None:
            if user.type == 'U':
                reports = Report.objects.filter(posted_by=user).order_by('-lastedited')
                report=ReportSerializerShort(reports, many=True, context={'request': request})
                return Response({"reports": report.data})
            elif user.type == 'C':
                programs = Program.objects.filter(posted_by=user).order_by('-lastedited')
                reports = Report.objects.filter(program__in=programs).order_by('-lastedited')
                report=ReportSerializerShort(reports, many=True, context={'request': request})
                return Response({"reports": report.data})
            elif user.type == 'Ct':
                programs = Program.objects.filter(posted_by=user.refuser).order_by('-lastedited')
                reports = Report.objects.filter(program__in=programs).order_by('-lastedited')
                report=ReportSerializerShort(reports, many=True, context={'request': request})
                return Response({"reports": report.data})
            else:
                return Response({"reports": "Unauthorized"})
    if request.method == 'POST':
        if user.type == 'U':
            # print(request.data['impact'])
          #  print(request.data)
            if 'photo0' in request.data:
                # print(request.data['photo1'])
                name = request.data['photo0'].name
                if name.split('.')[1] not in ['png','jpg','jpeg']:
                    return Response({'error': True,'message': 'Please Upload a proper image'})
            if 'photo1' in request.data:
                # print(request.data['photo1'])
                name = request.data['photo1'].name
                if name.split('.')[1] not in ['png','jpg','jpeg']:
                    return Response({'error': True,'message': 'Please Upload a proper image'})
            if 'photo2' in request.data:
                # print(request.data['photo1'])
                name = request.data['photo2'].name
                if name.split('.')[1] not in ['png','jpg','jpeg']:
                    return Response({'error': True,'message': 'Please Upload a proper image'})
            if 'title' in request.data:
                if len(request.data['title']) < 1:
                    return Response({'error': True,'message': 'Please Enter a title'})
            else:
                return Response({'error': True,'message': 'Please Enter a title'})
            try:
                program = Program.objects.get(title=pid)
            except:
                return Response({'error': True,'message': 'Program not found'})
            try:
                scope = Scope.objects.get(id=request.data['scope'])
            except:
                return Response({'error': True,'message': 'Asset not found'})
            if 'weakness' in request.data:
                if len(request.data['weakness']) < 1:
                    return Response({'error': True,'message': 'Please Enter a Weakness'})
            if Report.objects.filter(title=request.data['title']).exists():
                return Response({"error": True,"message": "Report already exists with this title"})
            rep = Report(program=program, asset= scope, title=request.data['title'], impact=request.data['impact'], description=request.data['description'], 
            severity=request.data['severity'], weakness=request.data['weakness'], posted_by = user,
            photo0=request.data['photo0'] if 'photo0' in request.data else None, 
            photo1=request.data['photo1'] if 'photo1' in request.data else None, 
            photo2=request.data['photo2'] if 'photo2' in request.data else None,)
            rep.save()
            # programs = Report(title=request.da)
            # program=ProgramSerializerMore(programs, many=False, context={'request': request})
            # return Response(program.data)
            return Response({"show": True,"message": "Report Successfully Added"})
        else:
            return Response({"report": "Unauthorized"})


@api_view(['GET','POST'])
@authentication_classes([JWTTokenUserAuthentication])
@permission_classes([IsAuthenticated])
def specreport(request, rid=None,type='1'):
    user = User.objects.get(id=request.user.id)
    report = Report.objects.get(id=rid)
    if not check_report_perm(user, report):
        return Response({"report": "Unauthorized","error": True,"message": "Report Unauthorized"})
    # if rid:
    #     rid = rid.replace('+',' ')
    # print(pid)
    if request.method == 'GET':
        reportspec=ReportSerializerLong(report, many=False, context={'request': request})
        comment = Comment.objects.filter(report=report)
        comments = CommentSerializer(comment, many=True, context={'request': request} ) 
        return Response({"report": reportspec.data, "timeline": comments.data})
    if request.method == 'POST':
        if user.type == 'U':
            if type == '1':
                newcomment = Comment(report=report, posted_by=user, body=request.data['body'])
                newcomment.save()
                # return Response({"show": True,"message": "Comment Successfully Added"})
            elif type == '2':
                newcomment = Comment(report=report, posted_by=user, type='D',request=True)
                newcomment.save()
                # return Response({"show": True,"message": "Request Successfully Sent"})
            elif type == '3':
                newcomment = Comment(report=report, posted_by=user, type='A',request=True)
                newcomment.save()
                # return Response({"show": True,"message": "Request Successfully Sent"})
            else:
                return Response({"error": True,"message": "Something went wrong"})
            reportspec=ReportSerializerLong(report, many=False, context={'request': request})
            comment = Comment.objects.filter(report=report)
            comments = CommentSerializer(comment, many=True, context={'request': request} ) 
            return Response({"report": reportspec.data, "timeline": comments.data})
            return Response({"show": True,"message": "Comment Successfully Added"})
        elif user.type == 'Ct' or user.type == 'C' :
            messages = None
            if type == '1':
                newcomment = Comment(report=report, posted_by=user, body=request.data['body'])
                newcomment.save()
                # return Response({"show": True,"message": "Comment Successfully Added"})
            elif type == '2':
                newcomment = Comment(report=report, posted_by=user, type='D')
                newcomment.save()
                report.disclosure = True
                report.save()
                messages = 'Report was successfully made Public '
            elif type == '3':
                # newcomment = Comment(report=report, posted_by=user, type='A',request=True)
                # newcomment.save()
                return Response({"show": True,"message": "Request Successfully Sent"})
            elif type == '4':
                newcomment = Comment(report=report, posted_by=user, type='D2')
                newcomment.save()
                report.disclosure = False
                report.save()
                messages = 'Report Hidden Successfully'
                # return Response({"show": True,"message": "Request Successfully Sent"})
            elif type == '5':
                newcomment = Comment(report=report, posted_by=user, type='T',body=request.data['thanks'])
                newcomment.save()
                thanks = Thanks(fro=user,to=report.posted_by,description=request.data['description'],reputation=request.data['thanks'])
                thanks.save()
                thanked = User.objects.get(id=report.posted_by.id)
                thanked.otherreputation += request.data['thanks']
                thanked.save()
                program = Program.objects.get(id=report.program.id)
                program.thanks.add(thanks)
                program.save()
                messages = 'Thanks was successfully sent'
            else:
                return Response({"error": True,"message": "Something went wrong"})
            reportspec=ReportSerializerLong(report, many=False, context={'request': request})
            comment = Comment.objects.filter(report=report)
            comments = CommentSerializer(comment, many=True, context={'request': request} ) 
            resp = {"report": reportspec.data, "timeline": comments.data}
            if messages:
                resp["message"] = messages
                resp["show"] = True
            # print(resp)
            return Response(resp)
            return Response({"show": True,"message": "Comment Successfully Added"})
        else:
            return Response({"report": "Unauthorized"})