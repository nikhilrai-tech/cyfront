from django.apps import AppConfig


class BackConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'back'
    verbose_name = 'Authentication'
