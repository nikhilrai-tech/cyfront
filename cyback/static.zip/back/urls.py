
from django.urls import path
from django.conf.urls import url
from django.conf.urls import include
from rest_framework.authtoken import views
from . import oldbviews

urlpatterns = [
    path('login',oldbviews.login),
    path('signup',oldbviews.signup),
    path('forgotsend/<id>',oldbviews.forgotsend),
    path('forgotpassword',oldbviews.forgotpassword),
    path('verify',oldbviews.verify2),
    path('sendagain',oldbviews.sendagain),
    path('changepassword',oldbviews.change),
    path('profiling',oldbviews.profile),
    path('propic',oldbviews.propic),
    path('profiling/<user>',oldbviews.profile),
    path('repusers',oldbviews.usersbyrep),
    path('repusers/<full>',oldbviews.usersbyrep),
    path('authusers',oldbviews.authusers),
    path('nonauthusers',oldbviews.nonauthusers), 
    path('contact',oldbviews.contact), 
    # url(r'^$', oldbviews.index),
    # url(r'^(?:.*)/?$', oldbviews.index),
]